# ICare247 — Hướng Dẫn Sử Dụng AI Agent

> Tài liệu này hướng dẫn cách configure và sử dụng AI agent  
> (Claude, Cursor, GitHub Copilot) hiệu quả trong project ICare247.

---

## 1. CÁC FILE CẤU HÌNH AI AGENT

Sau khi chạy `setup_icare247.sh`, copy tất cả file sau vào đúng vị trí:

```
ICare247_Core/                        ← root project
│
├── CLAUDE.md                         ← [CHÍNH] Claude & Cursor đọc file này
├── .cursorrules                      ← Cursor IDE rules
├── .editorconfig                     ← Code style (mọi editor)
│
├── .github/
│   └── copilot-instructions.md       ← GitHub Copilot instructions
│
├── .vscode/
│   ├── settings.json                 ← VS Code settings
│   └── extensions.json               ← Extensions khuyến nghị
│
└── docs/
    ├── 00_PROJECT_OVERVIEW.md
    ├── 01_ARCHITECTURE.md
    ├── 02_DATABASE_SCHEMA.md         ← Agent tra cứu khi viết Dapper query
    ├── 03_GRAMMAR_V1_SPEC.md         ← Agent tra cứu khi viết AST code
    ├── 04_ENGINE_SPEC.md             ← Agent tra cứu khi viết Engine
    ├── 05_ACTION_RULE_PARAM_SCHEMA.md ← Agent tra cứu JSON schemas
    ├── 06_SOLUTION_STRUCTURE.md      ← Agent tra cứu file/folder structure
    ├── 07_API_CONTRACT.md            ← Agent tra cứu khi viết Controller
    └── 08_CONVENTIONS.md             ← Agent tra cứu cache keys, SQL patterns
```

---

## 2. SETUP THEO TỪNG AI TOOL

### 2.1 Claude (claude.ai hoặc Claude API)

**Cách tốt nhất:** Tạo Project trong claude.ai và attach tất cả docs:

1. Tạo Project mới trên claude.ai: **"ICare247 Core"**
2. Upload tất cả file trong `docs/` vào Project Knowledge
3. Upload `CLAUDE.md` vào Project Knowledge
4. Claude sẽ tự động đọc context này trong mọi conversation

**Prompt mẫu khi yêu cầu Claude generate code:**
```
Tôi cần implement [tên class]. 
File này thuộc layer [Domain/Application/Infrastructure/Api], module [Metadata/Grammar/Validation/Event].
Namespace: [ICare247.xxx.xxx]
Tuân theo CLAUDE.md và conventions trong docs/08_CONVENTIONS.md.
```

---

### 2.2 Cursor IDE

1. Copy `.cursorrules` vào root của project (`ICare247_Core/.cursorrules`)
2. Copy `CLAUDE.md` vào root
3. Mở project trong Cursor: `cursor ICare247_Core`
4. Cursor tự động đọc `.cursorrules` cho mọi AI request

**Sử dụng Cursor Chat (@file):**
```
@docs/02_DATABASE_SCHEMA.md 
Implement FormRepository theo đúng schema. Namespace: ICare247.Infrastructure.Persistence.Metadata
```

**Sử dụng Cursor Composer (Ctrl+I):**
```
@CLAUDE.md @docs/08_CONVENTIONS.md
Tạo GetFormByCodeQueryHandler.cs trong Application/Metadata/Handlers/
```

---

### 2.3 GitHub Copilot (VS Code)

1. Copy `.github/copilot-instructions.md` vào đúng đường dẫn
2. Cài extension **GitHub Copilot** + **GitHub Copilot Chat** trong VS Code
3. Copilot tự động đọc `.github/copilot-instructions.md`

**Sử dụng Copilot Chat (#file):**
```
#file:docs/04_ENGINE_SPEC.md
Implement ValidationEngine.cs theo spec. 
```

**Copilot inline (Tab completion):**  
Copilot sẽ tự động suggest code theo đúng pattern trong project sau khi có vài file mẫu.

---

## 3. PROMPT TEMPLATES HIỆU QUẢ

### 3.1 Tạo Domain Entity

```
Tạo file [FileName].cs

Yêu cầu:
- Layer: Domain — Entities/[Folder]/
- Namespace: ICare247.Domain.Entities.[Folder]
- Map từ bảng DB: [TableName] (xem docs/02_DATABASE_SCHEMA.md)
- Pure C# class, không dependency nào ngoài Domain
- File header comment đầy đủ
- XML doc comments tiếng Việt cho mọi property
- Dùng `init` properties (immutable)
```

### 3.2 Tạo Repository Interface

```
Tạo [IXxxRepository].cs

Yêu cầu:
- Layer: Application — Common/Interfaces/
- Namespace: ICare247.Application.Common.Interfaces
- Methods: GetByIdAsync, GetByCodeAsync, GetByFormIdAsync (xem naming convention)
- Mọi method có CancellationToken ct = default
- Mọi method trả IReadOnlyList<T> hoặc T? (không List<T>)
- XML doc comments tiếng Việt
```

### 3.3 Tạo Dapper Repository

```
Implement [XxxRepository].cs

Yêu cầu:
- Implements I[Xxx]Repository (đã có trong Application.Common.Interfaces)
- Layer: Infrastructure — Persistence/[Module]/
- Namespace: ICare247.Infrastructure.Persistence.[Module]
- Inject IDbConnectionFactory (không inject IDbConnection trực tiếp)
- Mọi method: using var conn = _connectionFactory.CreateConnection()
- Mọi query: CommandDefinition với cancellationToken
- Không SELECT *, liệt kê rõ cột cần thiết
- Mọi query có @TenantId trong WHERE
- Tham chiếu schema: docs/02_DATABASE_SCHEMA.md
```

### 3.4 Tạo CQRS Query + Handler

```
Tạo [GetXxxByYyyQuery].cs và [GetXxxByYyyQueryHandler].cs

Query yêu cầu:
- Layer: Application — [Module]/Queries/
- Pattern: record GetXxxByYyyQuery(...) : IRequest<ReturnType>

Handler yêu cầu:
- Layer: Application — [Module]/Handlers/
- Inject interface qua constructor (không inject implementation)
- Return type rõ ràng
- Xử lý null case
- Log performance nếu cần
```

### 3.5 Tạo Function Handler (Grammar V1)

```
Tạo [FunctionCode]FunctionHandler.cs

Yêu cầu:
- Implements IFunctionHandler
- Layer: Infrastructure — Grammar/Functions/[String|Numeric|DateTime|Logic]/
- FunctionCode phải khớp với Gram_Function.Function_Code trong DB (xem SeedData)
- Execute: nhận args đã type-convert, trả object? (không throw cho null input)
- Tham chiếu: docs/03_GRAMMAR_V1_SPEC.md và db/ICare247_SeedData.sql
```

---

## 4. CONTEXT CUNG CẤP CHO AGENT KHI CẦN

### Khi viết Dapper query → cung cấp schema:
```
Tham chiếu bảng từ docs/02_DATABASE_SCHEMA.md:
[paste section liên quan từ DB schema]
```

### Khi viết AST code → cung cấp spec:
```
Tham chiếu từ docs/03_GRAMMAR_V1_SPEC.md:
[paste phần AST node types liên quan]
```

### Khi viết Controller → cung cấp contract:
```
Tham chiếu từ docs/07_API_CONTRACT.md:
[paste endpoint spec liên quan]
```

### Khi viết Action handler → cung cấp JSON schema:
```
Tham chiếu từ docs/05_ACTION_RULE_PARAM_SCHEMA.md:
[paste action schema liên quan]
```

---

## 5. LỖI THƯỜNG GẶP VÀ CÁCH FIX

| Lỗi | Nguyên nhân | Fix |
|---|---|---|
| Agent dùng EF Core | Không đọc rules | Nhắc lại: "Dapper ONLY, no EF Core" |
| Agent SELECT * | Không đọc conventions | Nhắc: "Không SELECT *, liệt kê rõ cột" |
| Agent thiếu @TenantId | Quên multi-tenant | Nhắc: "Mọi query phải có @TenantId" |
| Agent hardcode cache key | Không biết CacheKeys.cs | Cung cấp nội dung CacheKeys.cs |
| Agent thiếu CancellationToken | Sót | Nhắc: "CancellationToken ct = default trên mọi async method" |
| Namespace sai | Agent tự đặt | Chỉ rõ: "Namespace: ICare247.xxx.xxx" |
| Agent dùng JsonElement trong engine | Không đọc rules | Nhắc: "Convert JsonElement sang C# type trước khi đưa vào AST" |

---

## 6. WORKFLOW ĐỀ XUẤT

```
Với mỗi task:

1. Xác định layer (Domain/Application/Infrastructure/Api)
2. Xác định namespace (ICare247.xxx.xxx)
3. Tham chiếu docs liên quan (DB schema, Engine spec, API contract)
4. Provide CLAUDE.md hoặc .cursorrules làm context
5. Request generate code với template tương ứng (mục 3)
6. Review theo checklist (mục 7)
7. Đăng ký DI trong DependencyInjection.cs nếu cần
```

---

## 7. CHECKLIST REVIEW CODE DO AGENT GENERATE

```
□ File header đúng format (File/Module/Layer/Purpose)?
□ XML doc comments có đủ không?
□ Namespace khớp folder path?
□ CancellationToken có trên mọi async method?
□ Dapper query không có SELECT *?
□ SQL không có string interpolation?
□ @TenantId có trong WHERE clause?
□ using var conn = _connectionFactory.CreateConnection()?
□ Cache key lấy từ CacheKeys.cs?
□ Không có empty catch block?
□ Interface đã thêm vào DependencyInjection.cs?
□ 1 file = 1 class/interface/record?
```
