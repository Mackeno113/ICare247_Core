# GitHub Copilot Instructions — ICare247 Core Platform

Đây là hướng dẫn cho GitHub Copilot khi làm việc trong project ICare247.
Copilot phải tuân theo tất cả quy tắc dưới đây khi generate code.

## Project Context
- Enterprise metadata-driven form engine, .NET 9
- Clean Architecture: Domain / Application / Infrastructure / Api
- Mọi form, rule, event cấu hình trong DB — không hardcode trong code

## Non-negotiable Rules

1. **Data Access**: Chỉ Dapper. Không EF Core. Không raw SqlCommand.
2. **Multi-tenant**: Mọi Dapper query phải có `AND Tenant_Id = @TenantId`.
3. **Cache Keys**: Luôn lấy từ `CacheKeys.cs`. Không hardcode string.
4. **CancellationToken**: Mọi async method nhận `CancellationToken ct = default`.
5. **SQL Safety**: Không `SELECT *`. Không string interpolation trong SQL.
6. **Error Handling**: Không swallow exception. Không empty catch. Bubble up.
7. **One class per file**: Không gộp nhiều class trong 1 file.
8. **Namespace = folder path**: `ICare247.Infrastructure.Persistence.Metadata`.
9. **AST null safety**: Identifier không tồn tại → return null, không throw.
10. **No .Result/.Wait()**: async/await xuyên suốt.

## Preferred Patterns

**Repository method:**
```csharp
public async Task<T?> GetByCodeAsync(string code, int tenantId, CancellationToken ct)
{
    const string sql = "SELECT Col1, Col2 FROM dbo.Table WHERE Code = @Code AND Tenant_Id = @TenantId AND Is_Active = 1";
    using var conn = _connectionFactory.CreateConnection();
    return await conn.QueryFirstOrDefaultAsync<T>(
        new CommandDefinition(sql, new { Code = code, TenantId = tenantId }, cancellationToken: ct));
}
```

**MediatR Query:**
```csharp
public record GetFormByCodeQuery(string FormCode, int TenantId, string LangCode) : IRequest<FormDto?>;

public class GetFormByCodeQueryHandler : IRequestHandler<GetFormByCodeQuery, FormDto?>
{
    public async Task<FormDto?> Handle(GetFormByCodeQuery request, CancellationToken ct) { ... }
}
```

**Serilog (structured, no interpolation):**
```csharp
// ✅ CORRECT
_logger.LogInformation("Form loaded. FormCode={FormCode} Duration={Duration}ms", formCode, duration);
// ❌ WRONG
_logger.LogInformation($"Form loaded: {formCode}");
```
