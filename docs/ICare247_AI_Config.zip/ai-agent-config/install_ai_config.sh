#!/bin/bash
# ============================================================
#  ICare247 — Install AI Agent Config Files
#  Chạy script này SAU khi đã chạy setup_icare247.sh
#  Usage: ./install_ai_config.sh [path-to-ICare247_Core]
# ============================================================

set -e

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
print_step() { echo -e "\n${CYAN}===> $1${NC}"; }

# ── Xác định thư mục đích ──────────────────────────────────
if [ -n "$1" ]; then
  TARGET="$1"
elif [ "$(basename "$PWD")" = "ICare247_Core" ]; then
  TARGET="$PWD"
else
  TARGET="$PWD/ICare247_Core"
fi

if [ ! -d "$TARGET" ]; then
  echo "Không tìm thấy thư mục: $TARGET"
  echo "Usage: ./install_ai_config.sh [path-to-ICare247_Core]"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

print_step "Cài AI config files vào: $TARGET"

# ── CLAUDE.md → root ──────────────────────────────────────
cp "$SCRIPT_DIR/CLAUDE.md"       "$TARGET/CLAUDE.md"
print_ok "CLAUDE.md → root"

# ── .cursorrules → root ───────────────────────────────────
cp "$SCRIPT_DIR/.cursorrules"    "$TARGET/.cursorrules"
print_ok ".cursorrules → root"

# ── .editorconfig → root ──────────────────────────────────
cp "$SCRIPT_DIR/.editorconfig"   "$TARGET/.editorconfig"
print_ok ".editorconfig → root"

# ── .github/copilot-instructions.md ──────────────────────
mkdir -p "$TARGET/.github"
cp "$SCRIPT_DIR/.github/copilot-instructions.md" "$TARGET/.github/copilot-instructions.md"
print_ok ".github/copilot-instructions.md"

# ── .vscode/settings.json + extensions.json ──────────────
mkdir -p "$TARGET/.vscode"
cp "$SCRIPT_DIR/.vscode/settings.json"    "$TARGET/.vscode/settings.json"
cp "$SCRIPT_DIR/.vscode/extensions.json"  "$TARGET/.vscode/extensions.json"
print_ok ".vscode/settings.json + extensions.json"

# ── docs/AI_AGENT_GUIDE.md ───────────────────────────────
mkdir -p "$TARGET/docs"
cp "$SCRIPT_DIR/docs/AI_AGENT_GUIDE.md"  "$TARGET/docs/AI_AGENT_GUIDE.md"
print_ok "docs/AI_AGENT_GUIDE.md"

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  AI Agent Config đã cài xong!${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo "  Cấu trúc files đã cài:"
echo "  ├── CLAUDE.md                         ← Claude + Cursor đọc đây"
echo "  ├── .cursorrules                       ← Cursor IDE rules"
echo "  ├── .editorconfig                      ← Code style"
echo "  ├── .github/copilot-instructions.md    ← GitHub Copilot"
echo "  ├── .vscode/settings.json              ← VS Code settings"
echo "  ├── .vscode/extensions.json            ← Extensions khuyến nghị"
echo "  └── docs/AI_AGENT_GUIDE.md             ← Hướng dẫn dùng AI agent"
echo ""
echo -e "  Bước tiếp theo:"
echo -e "  1. ${YELLOW}Mở VS Code: code $TARGET${NC}"
echo -e "  2. Install extensions được đề xuất (popup góc phải)"
echo -e "  3. Đọc docs/AI_AGENT_GUIDE.md để biết cách prompt hiệu quả"
echo ""
