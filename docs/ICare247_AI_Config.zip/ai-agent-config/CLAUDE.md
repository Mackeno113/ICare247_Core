# ICare247 Core Platform — AI Agent Instructions

> **Đây là file cấu hình chính cho AI agent (Claude, Copilot, Cursor, v.v.)**  
> Agent PHẢI đọc file này trước khi generate bất kỳ code nào trong project.  
> Tài liệu chi tiết trong `docs/` — tham chiếu khi cần thêm context.

---

## 1. TỔNG QUAN DỰ ÁN

ICare247 Core Platform là **enterprise metadata-driven low-code form engine**.  
Toàn bộ form, validation, event được định nghĩa trong **database** — không hardcode trong code.

### Hai sản phẩm:
- **Core Runtime Engine** — đọc metadata → thực thi form, validation, event
- **Config Studio** — authoring tool → tạo/quản lý metadata

### Tech Stack:
| Thành phần | Công nghệ |
|---|---|
| Backend | .NET 9 / ASP.NET Core 9 |
| Frontend | Blazor WebAssembly + DevExpress Blazor |
| Database | MS SQL Server |
| Data Access | **Dapper ONLY** — KHÔNG dùng EF Core |
| Cache | MemoryCache (L1) + Redis (L2) |
| Logging | Serilog + OpenTelemetry |
| Auth | JWT + Policy-based Authorization |

---

## 2. KIẾN TRÚC — CLEAN ARCHITECTURE 4 LAYER

```
ICare247.Domain         ← Entities, AST Nodes, Engine Interfaces, ValueObjects, Exceptions
ICare247.Application    ← CQRS (MediatR), Use Cases, Repository Interfaces
ICare247.Infrastructure ← Dapper, Redis, Serilog, AST Engine implementations
ICare247.Api            ← Controllers, Middleware, Swagger
```

### Dependency Rules (BẮT BUỘC):
```
Domain          ← KHÔNG import bất kỳ project nào
Application     ← CHỈ import Domain
Infrastructure  ← import Application (để implement interfaces)
Api             ← CHỈ import Application (KHÔNG import Infrastructure trực tiếp)
```

> `Api` layer không bao giờ `new` trực tiếp bất kỳ class nào từ `Infrastructure`.  
> DI Container trong `Program.cs` gọi: `AddApplication()` và `AddInfrastructure()`.

---

## 3. QUY TẮC CODE — BẮT BUỘC TUYỆT ĐỐI

### ✅ PHẢI LÀM:
```
✅ Mọi async method nhận CancellationToken ct = default
✅ Mọi Dapper query dùng CommandDefinition với cancellationToken
✅ Mọi cache key lấy từ CacheKeys.cs — không hardcode string
✅ Mọi log message dùng structured template {Property} — không $"string interpolation"
✅ Repository dùng using var conn = _connectionFactory.CreateConnection() trong mọi method
✅ AST Engine: không throw khi identifier null hoặc divide by zero → trả NULL
✅ Exception phải bubble lên — không try/catch nuốt trong engine
✅ Mọi string comparison với DB values: StringComparison.OrdinalIgnoreCase
✅ Mọi query phải có @TenantId trong WHERE clause (multi-tenant isolation)
✅ Namespace phải khớp với folder path
✅ Mỗi file = đúng 1 class/interface/record
✅ Async/await xuyên suốt — không .Result hay .Wait()
```

### ❌ TUYỆT ĐỐI KHÔNG:
```
❌ Không dùng EF Core — chỉ Dapper
❌ Không hardcode cache key string ngoài CacheKeys.cs
❌ Không dùng JsonElement trực tiếp trong AST engine
❌ Không SELECT * trong bất kỳ SQL query nào
❌ Không string interpolation trong SQL ($"SELECT ... {var}")
❌ Không .Result hoặc .Wait() trên Task
❌ Không new Repository() trong controller hoặc handler
❌ Không swallow exception trong Validation/Event/AST engine
❌ Không dùng static field để track mutable state trong engine (thread-unsafe)
❌ Không ghi Sys_Perf_Log bằng synchronous call trong hot path
```

---

## 4. NAMING CONVENTIONS

### C# General:
| Loại | Convention | Ví dụ |
|---|---|---|
| Class | PascalCase | `FormMetadata`, `AstParser` |
| Interface | `I` + PascalCase | `IFormRepository`, `IAstEngine` |
| Method | PascalCase + `Async` suffix | `GetByCodeAsync`, `EvaluateAsync` |
| Private field | `_` + camelCase | `_repository`, `_cache` |
| Local variable | camelCase | `formMetadata`, `ruleList` |
| Constant | PascalCase | `MaxAstDepth` |

### CQRS Pattern:
```
Query:   Get{Object}By{Key}Query          → GetFormByCodeQuery
Handler: Get{Object}By{Key}QueryHandler   → GetFormByCodeQueryHandler
Command: {Verb}{Object}Command            → ValidateFieldCommand
Handler: {Verb}{Object}CommandHandler     → ValidateFieldCommandHandler
```

### Repository Methods:
| Action | Method | Return |
|---|---|---|
| Lấy 1 theo key | `GetByIdAsync(int id, CancellationToken ct)` | `T?` |
| Lấy 1 theo code | `GetByCodeAsync(string code, CancellationToken ct)` | `T?` |
| Lấy nhiều theo FK | `GetByFormIdAsync(int formId, CancellationToken ct)` | `IReadOnlyList<T>` |
| Tồn tại không | `ExistsAsync(..., CancellationToken ct)` | `bool` |

### Function Handler Pattern:
```
len → LenFunctionHandler.cs
trim → TrimFunctionHandler.cs
```

---

## 5. FILE HEADER — MỌI FILE .CS ĐỀU CÓ

```csharp
// ============================================================
// File    : FormRepository.cs
// Module  : Metadata
// Layer   : Infrastructure — Persistence
// Purpose : Truy vấn Dapper cho Ui_Form. Load form metadata từ DB,
//           hỗ trợ cache invalidation theo version.
// ============================================================
```

---

## 6. XML DOC COMMENTS

Mọi class, interface, public method đều có XML doc comments bằng **tiếng Việt**:

```csharp
/// <summary>
/// Repository truy vấn dữ liệu form từ bảng <c>Ui_Form</c>.
/// Tất cả query parameterized. Cache invalidation theo Version.
/// </summary>
public class FormRepository : IFormRepository

/// <summary>
/// Load metadata form theo Form_Code. Trả về <c>null</c> nếu không tìm thấy.
/// </summary>
/// <param name="formCode"><c>Ui_Form.Form_Code</c> — unique identifier của form.</param>
/// <param name="ct">Cancellation token.</param>
/// <returns><see cref="FormMetadata"/> nếu tìm thấy; <c>null</c> nếu không tồn tại.</returns>
public async Task<FormMetadata?> GetByCodeAsync(string formCode, CancellationToken ct)
```

---

## 7. DAPPER QUERY PATTERN

```csharp
// ✅ ĐÚNG
public async Task<FormMetadata?> GetByCodeAsync(string formCode, int tenantId, CancellationToken ct)
{
    const string sql = """
        SELECT
            f.Form_Id,
            f.Form_Code,
            f.Title,
            f.Version,
            f.Is_Active
        FROM  dbo.Ui_Form f
        WHERE f.Form_Code = @FormCode
          AND f.Tenant_Id = @TenantId   -- LUÔN có TenantId
          AND f.Is_Active = 1
        """;

    using var conn = _connectionFactory.CreateConnection();
    return await conn.QueryFirstOrDefaultAsync<FormMetadata>(
        new CommandDefinition(sql, new { FormCode = formCode, TenantId = tenantId }, cancellationToken: ct));
}
```

---

## 8. CACHE KEY CONVENTION

Tất cả cache key phải định nghĩa trong `ICare247.Infrastructure/Cache/CacheKeys.cs`:

```csharp
// ✅ ĐÚNG
var cacheKey = CacheKeys.Form(formCode, version, langCode, platform);

// ❌ SAI — không hardcode
var cacheKey = $"form:{formCode}:v{version}";
```

---

## 9. AST NODE — 3-VALUE LOGIC

AST Engine áp dụng 3-value logic:
- `TRUE` → pass / condition met
- `FALSE` → fail / condition not met  
- `NULL` → pass (không fail, null-safe)

```csharp
// Identifier không tồn tại trong context → NULL (không throw)
// Divide by zero → NULL (không throw)
// System exception → bubble lên (không swallow)
```

---

## 10. SQL TYPE → .NET TYPE MAPPING

Dùng khi build `EvaluationContext` và Dynamic Model:

| SQL Type | .NET Type | `Net_Type` string |
|---|---|---|
| `nvarchar`, `varchar` | `string?` | `String` |
| `int`, `smallint` | `int?` | `Int32` |
| `bigint` | `long?` | `Int64` |
| `decimal`, `numeric`, `money` | `decimal?` | `Decimal` |
| `float`, `real` | `double?` | `Double` |
| `bit` | `bool?` | `Boolean` |
| `datetime`, `datetime2`, `date` | `DateTime?` | `DateTime` |
| `uniqueidentifier` | `Guid?` | `Guid` |

---

## 11. CHECKLIST TRƯỚC KHI GENERATE CODE

Agent tự kiểm tra trước khi output bất kỳ file `.cs` nào:

```
□ File header có đủ: File, Module, Layer, Purpose?
□ Mọi class/interface có /// <summary>?
□ Mọi public method có /// <summary>, /// <param>, /// <returns>?
□ Method có thể throw → có /// <exception>?
□ Cache key dùng CacheKeys.cs?
□ Tất cả async method có CancellationToken?
□ SQL query parameterized (@Param)? Không có $"..."?
□ Log message dùng {Property} template? Không $"..."?
□ Repository dùng using var conn = _factory.CreateConnection()?
□ Không SELECT * trong query?
□ Exception không bị swallow?
□ Singleton service không có mutable state?
□ Interface đã đăng ký trong DependencyInjection.cs?
□ Namespace khớp folder path?
□ Có @TenantId trong SQL query?
```

---

## 12. TÀI LIỆU THAM CHIẾU

| File | Nội dung |
|---|---|
| `docs/00_PROJECT_OVERVIEW.md` | Tổng quan, mục tiêu, tech stack, phases |
| `docs/01_ARCHITECTURE.md` | Clean Architecture, cache, security |
| `docs/02_DATABASE_SCHEMA.md` | Toàn bộ schema bảng DB |
| `docs/03_GRAMMAR_V1_SPEC.md` | Grammar V1 AST specification |
| `docs/04_ENGINE_SPEC.md` | Engine specs: AST, Validation, Event, Metadata |
| `docs/05_ACTION_RULE_PARAM_SCHEMA.md` | JSON schema cho Action params & Rule expressions |
| `docs/06_SOLUTION_STRUCTURE.md` | Cấu trúc solution, naming conventions |
| `docs/07_API_CONTRACT.md` | REST API endpoints, request/response format |
| `docs/08_CONVENTIONS.md` | Coding conventions đầy đủ, cache keys, SQL patterns |
| `db/ICare247_SeedData.sql` | Dữ liệu mẫu — danh sách đầy đủ 44 functions |
